<!-- Modal -->
<div class="modal modal-right fade " id="filter">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="side-modal-wrapper">
                <form action="<?php echo e(route('admin.listings.index')); ?>" method="get">
                    
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Filter</h5>
                    
                </div>

                <div class="modal-body">
                    
                        <div class="form-group">
                          <label for="">Search With Name</label>
                          <input type="text"
                            class="form-control" name="name" id="name" value="<?php echo e(request()->get('name','')); ?>" aria-describedby="helpId" placeholder="">
                        </div>
                        <div class="form-group">
                            <label for="">Search With Type</label>
                            <select name="type_id" id="" class="select2">
                                <option value="">Select Type</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Search With Category</label>
                            <select name="category_id" id="" class="select2">
                                <option value="">Select Category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="">Search With City</label>
                            <select name="city_id" id="" class="select2">
                                <option value="">Select City</option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        
                        <div class="form-group">
                            <label for="">Search With Status</label>
                            <select name="status" id="" class="form-control">
                                <?php if(request()->get('status') == '0'): ?>
                                <option value="0">Inactive</option>
                                <?php else: ?>
                                <option value="1">Active</option>
                                <?php endif; ?>
                                <option value="1">Active</option>
                                <option value="0">Inactive</option>
                                
                            </select>
                        </div>

                        
                    
                </div>
                <div class="modal-footer">
                    <a type="button" class="btn btn-default mr-3" href="<?php echo e(route('admin.listings.index')); ?>">Reset</a>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>

            </form>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\Freelance\Lisiting Agency\lisiting-agency\resources\views/admin/listings/parts/filter_form.blade.php ENDPATH**/ ?>