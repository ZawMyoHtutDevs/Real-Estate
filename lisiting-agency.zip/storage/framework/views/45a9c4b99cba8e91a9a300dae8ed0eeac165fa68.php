
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header no-gutters">
    <div class="d-md-flex align-items-md-center justify-content-between">
        <div class="media m-v-10 align-items-center">
            <div class="avatar avatar-image avatar-lg">
                <img src="<?php echo e(asset('backend/images/logo/favicon.png')); ?>" alt="">
            </div>
            <div class="media-body m-l-15">
                <h4 class="m-b-0">Welcome back, <?php echo e(auth()->user()->name); ?>!</h4>
                <span class="text-gray">Admin</span>
            </div>
        </div>
        <div class="d-md-flex align-items-center d-none">
            <div class="media align-items-center m-r-40 m-v-5">
                <div class="font-size-27">
                    <i class="text-primary anticon anticon-profile"></i>
                </div>
                <div class="d-flex align-items-center m-l-10">
                    <h2 class="m-b-0 m-r-5"><?php echo e($listings); ?></h2>
                    <span class="text-gray">Listings</span>
                </div>
            </div>
            <div class="media align-items-center m-r-40 m-v-5">
                <div class="font-size-27">
                    <i class="text-success  anticon anticon-appstore"></i>
                </div>
                <div class="d-flex align-items-center m-l-10">
                    <h2 class="m-b-0 m-r-5"><?php echo e($categories); ?></h2>
                    <span class="text-gray">Categories</span>
                    
                </div>
            </div>
            <div class="media align-items-center m-v-5">
                <div class="font-size-27">
                    <i class="text-danger anticon anticon-team"></i>
                </div>
                <div class="d-flex align-items-center m-l-10">
                    <h2 class="m-b-0 m-r-5"><?php echo e($users); ?></h2>
                    <span class="text-gray">Accounts</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Latest 10 Contacts</h5>
                    <div>
                        <a href="<?php echo e(route('admin.contacts.index')); ?>" class="btn btn-default btn-sm">View All</a> 
                    </div>
                </div>
                <div class="table-responsive m-t-30">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Listing</th>
                                <th>Contact Info</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contacts_lat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($data->name); ?>

                                </td>

                                <td>
                                    <?php echo e($data->listing->name); ?>

                                </td>

                                <td>
                                    <?php echo e($data->contact_info); ?>

                                </td>
                                
                            
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
  
    </div>
    <div class="col-lg-4">
      <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <h5>Latest Listing</h5>
                
            </div>
            <div class="m-t-30">
                <ul class="list-group list-group-flush">
                  <?php $__currentLoopData = $listings_lat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item p-h-0">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="d-flex">
                                
                                <div>
                                    <h6 class="m-b-0">
                                        <a href="javascript:void(0);" class="text-dark"> <?php echo e($data->name); ?></a>
                                    </h6>
                                    <span class="text-muted font-size-13"><?php echo e($data->category->name); ?></span>
                                </div>
                            </div>
                            <a href="<?php echo e(route('frontend.listings.show', $data->id)); ?>" class="badge badge-pill badge-cyan font-size-12">
                                <span class="font-weight-semibold m-l-5">View</span>
                            </a>
                        </div>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul> 
            </div>
        </div>
    </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Lisiting Agency\lisiting-agency\resources\views/admin/index.blade.php ENDPATH**/ ?>