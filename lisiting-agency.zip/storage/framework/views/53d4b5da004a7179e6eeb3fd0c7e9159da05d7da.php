<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">

    <!-- CSRF Token -->
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />

    <title>Lisiting Agency - <?php echo e($page_action ?? ''); ?></title>
    <!-- Fav Icon -->
<link rel="icon" href="<?php echo e(asset('/assets/images/favicon.ico')); ?>" type="image/x-icon">

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    
    <?php echo $__env->yieldContent('style'); ?>
    <!-- Stylesheets -->
<link href="<?php echo e(asset('/assets/css/font-awesome-all.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/flaticon.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/owl.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/bootstrap.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/jquery.fancybox.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/jquery-ui.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('/assets/css/color/theme-color.css')); ?>" id="jssDefault" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/switcher-style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('/assets/css/responsive.css')); ?>" rel="stylesheet">
    

</head>
<body>
        <div class="boxed_wrapper">
            <!-- Header START -->
            <?php echo $__env->make('frontend.layouts.parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Header END -->

            <?php echo $__env->yieldContent('breadcrumb'); ?>
                    
            <?php echo $__env->yieldContent('content'); ?>
            <!-- Content  -->
            
            <!-- Footer START -->
            <?php echo $__env->make('frontend.layouts.parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Footer END -->
            
        </div>

    <!-- jequery plugins -->
    <script src="<?php echo e(asset('/assets/js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/owl.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/validation.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/jquery.fancybox.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/appear.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/scrollbar.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/isotope.js')); ?>"></script>
    
    <script src="<?php echo e(asset('/assets/js/jQuery.style.switcher.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/nav-tool.js')); ?>"></script>

    <!-- main-js -->
    <script src="<?php echo e(asset('/assets/js/script.js')); ?>"></script>
    <!-- page js -->
    <?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH D:\Freelance\Lisiting Agency\lisiting-agency\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>