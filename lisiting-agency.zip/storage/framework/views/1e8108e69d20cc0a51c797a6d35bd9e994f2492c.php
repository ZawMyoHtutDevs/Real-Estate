
<?php $__env->startSection('style'); ?>

<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header mb-3">
    <h2 class="header-title">Step One - Add Listing</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('admin')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <a class="breadcrumb-item" href="<?php echo e(route('admin.listings.index')); ?>">Listing</a>
            <span class="breadcrumb-item active">Step One - Add Listing</span>
        </nav>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<form method="GET" action="<?php echo e(route('admin.listings.create_st_one')); ?>" >
    <div class="row justify-content-center">
        <div class="col-md-7 mt-5">
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        
                        <div class="col-md-6">
                            <div class="form-group ">
                                <label for="type_id">Select Type</label>
                                <select class="select2" name="type_id" id="type_id " style="text-transform:capitalize;" required>
                                    <option value="" selected>Selete Type</option>                                
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group ">
                                <label for="region_id">Select Region</label>
                                <select class="select2" name="region_id" id="region_id " style="text-transform:capitalize;" required>
                                    <option value="" selected>Selete Type</option>                                
                                    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                        
                        
                    </div>
                    
                    
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary float-right">
                        Next
                        <i class="anticon anticon-double-right"></i>
                    </button>
                </div>
            </div>
            
        </div>
        
    </div>
    
</div>
</form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.js')); ?>"></script>
<script>    
    
    // select 2
    $('.select2').select2()
    
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', ['page_action' => 'Step One - Add Listing '], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Lisiting Agency\lisiting-agency\resources\views/admin/listings/create/step_one.blade.php ENDPATH**/ ?>