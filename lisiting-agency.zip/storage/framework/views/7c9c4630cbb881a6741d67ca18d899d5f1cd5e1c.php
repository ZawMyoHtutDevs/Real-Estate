
<?php $__env->startSection('style'); ?>
<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>

<div class="page-header no-gutters">
    <div class="row align-items-md-center">
        <div class="col-md-6">
            <div class="row">
                <div class="col-md-5">
                    <h3>Listing List</h3>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="text-md-right m-v-10">
                <span class="text-muted pr-3 pt-2 p">Total Result: <?php echo e(count($listings)); ?></span>
                
                <button class="btn btn-default m-r-5 ml-2 btn-sm" data-toggle="modal" data-target="#filter" >
                    <i class="anticon anticon-filter"></i>
                    <span class="m-l-5">Filter</span>
                </button>
                
                
                <a href="
                <?php echo e(route('admin.listings.create')); ?>

                " class="btn btn-primary m-r-5 ml-2 btn-sm">
                    <i class="anticon anticon-plus"></i>
                    <span class="m-l-5">New</span>
                </a>
                
            </div>
        </div>
    </div>
</div> 


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>


<div class="container-fluid">
    
    <div id="card-view">
        <div class="row">
            
            <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-6" style="padding-right: 5px;
            padding-left: 3px;">
            <div class="card" style="margin-bottom: 10px;">
                <div class="card-body" style="padding-top: 0.7em; padding-left: 0.3em; padding-right: 0.3em;">
                    
                    <div class="d-flex align-items-center p-2">
                        
                        <?php if($data->asset): ?>
                        <div class="avatar avatar-image avatar-badge avatar-square">
                            <img src="<?php echo e(asset('listing_photos/'.$data->asset)); ?>" alt="">
                            <?php if($data->status): ?>
                                <span class="badge badge-indicator badge-success"></span>
                            <?php else: ?>
                                <span class="badge badge-indicator badge-danger"></span>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        <div class="avatar avatar-icon avatar-blue avatar-badge avatar-square">
                            <i class="anticon anticon-picture"></i>
                            <?php if($data->status): ?>
                                <span class="badge badge-indicator badge-success"></span>
                            <?php else: ?>
                                <span class="badge badge-indicator badge-danger"></span>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                        
                        
                        
                        <div class="m-l-10">
                            <div class="m-b-0 text-dark font-weight-semibold"><?php echo e($data->price); ?> Lakhs </div>
                            

                            <div class="m-b-0 opacity-07 font-size-14"><?php echo e($data->type->name ?? 'null'); ?></div>
                        </div>

                    </div>
                    <hr style="margin-top: 5px; margin-bottom: 12px;">
                    <div class="d-flex align-items-center" style="word-wrap: break-word;
                    display: block !important;
                    height: 57px;">
                    
                    <div class="m-l-10">
                        <div class="m-b-0 text-dark font-weight-semibold">
                            <?php echo e($data->name); ?>                             
                        </div>

                        <div class="m-b-0 opacity-07 font-size-13 mt-3">
                            <span class="badge badge-pill badge-geekblue"><?php echo e($data->city->name ?? 'null'); ?></span>
                            <span class="badge badge-pill badge-geekblue"><?php echo e($data->category->name ?? 'null'); ?></span>
                        </div>
                    </div>
                </div>
                
                
            </div>
            <div class="card-footer" style="padding: 0.7rem;">
                <div class="text-right">
                    
                    

                    <a onclick="if(confirm('Are you sure you want to delete this data?')){document.getElementById('delete-form<?php echo e($data->id); ?>').submit(); }"  class="btn btn-default btn-xs">Delete</a>

                    <a href="<?php echo e(route('admin.listings.edit', $data->id)); ?>" class="btn btn-primary btn-xs">Edit</a>

                    <form id="delete-form<?php echo e($data->id); ?>" method="POST" action="<?php echo e(route('admin.listings.destroy', $data->id)); ?>" >
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?> 
                    </form>
                    
                </div>
            </div>
        </div>
        
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
</div>


<?php echo $listings->appends(array("name" => request()->get('name',''),"type_id" => request()->get('type_id',''),"category_id" => request()->get('category_id',''),"city_id" => request()->get('city_id',''), "status" => request()->get('status','') ))->links(); ?>

</div>



<?php echo $__env->make('admin.listings.parts.filter_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.min.js')); ?>"></script>
<script>
    $('.select2').select2();
    
    
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', ['page_action' => 'Listing List'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Lisiting Agency\lisiting-agency\resources\views/admin/listings/index.blade.php ENDPATH**/ ?>