
<?php $__env->startSection('style'); ?>
<style>
    /* image gallery */
    .image_custom {
        width: 100%;
        height: 150px;
        background-size: cover;
        background-position: center;
    }
    .delete_image_overly{
        display: none;
        width: 100%;
        height: 150px;
        background-color: #8080804f;
        margin-top: -150px;
    }
</style>
<!-- select css -->
<link href="<?php echo e(asset('backend/vendors/select2/select2.css')); ?>"  rel="stylesheet">
<?php $__env->stopSection(); ?>


<?php $__env->startSection('breadcrumb'); ?>
<div class="page-header mb-3">
    <h2 class="header-title">Add Listing</h2>
    <div class="header-sub-title">
        <nav class="breadcrumb breadcrumb-dash">
            <a href="<?php echo e(route('admin')); ?>" class="breadcrumb-item"><i class="anticon anticon-home m-r-5"></i>Dashboard</a>
            <a class="breadcrumb-item" href="<?php echo e(route('admin.listings.index')); ?>">Products</a>
            <span class="breadcrumb-item active">Add Listing</span>
        </nav>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        <span class="sr-only">Close</span>
    </button>
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('admin.listings.update', $listing->id)); ?>" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="row ">
        <div class="col-md-8">
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 ">
                            <div class="form-group">
                                <label for="name">Name  <small class="text-muted">*</small></label>
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name') ?? $listing->name); ?>" required autocomplete="name" autofocus >
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        <div class="col-12 col-md-6">
                            <div class="form-group">
                                <label for="category_id">Select Category <small class="text-muted">*</small></label>
                                <select class="select2" name="category_id" id="category_id" style="text-transform:capitalize;" required>

                                    <?php if($listing->category != ''): ?>
                                    <option value="<?php echo e($listing->category->id); ?>" selected><?php echo e($listing->category->name); ?></option>    
                                    <?php endif; ?>

                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-12 col-md-6">
                            <div class="form-group ">
                                <label for="city_id">Select City <small class="text-muted">*</small></label>
                                <select class="select2" name="city_id" id="city_id " style="text-transform:capitalize;" required>
                                    <?php if($listing->city != ''): ?>
                                    <option value="<?php echo e($listing->city->id); ?>" selected><?php echo e($listing->city->name); ?></option>    
                                    <?php endif; ?>                           
                                    <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"><?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        
                        
                        
                    </div>
                    
                    
                    
                    <div class="form-group">
                        <label for="">Description  <small class="text-muted">Optional</small></label>
                        <textarea name="description" class="form-control  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="description" rows="3"><?php echo old('description') ?? $listing->description; ?></textarea>
                    </div>
                    
                    
                </div>
                
            </div>
            
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <img src="<?php echo e(asset('listing_photos/'.$listing->asset)); ?>" class="img-fluid " width="100%" alt="">
                        </div>

                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="asset">New Main Photo <small class="text-muted">Optional</small></label>
                                <input id="asset" type="file" class="form-control <?php $__errorArgs = ['asset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asset" value="<?php echo e(old('asset')); ?>" autocomplete="asset" >
                                <?php $__errorArgs = ['asset'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger"><?php echo e($message); ?></p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <div class="form-group mt-3">
                        <label for="asset">New Gallery Photos <small class="text-muted">Optional</small></label>
                        <input id="gallery" type="file" class="form-control <?php $__errorArgs = ['gallery_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gallery_image[]" value="<?php echo e(old('gallery_image')); ?>" autocomplete="gallery" multiple>
                        <?php $__errorArgs = ['gallery_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="card-body">                    
                    
                    <h5>Gallery List</h5>
                    
                    <input type="hidden" name="delete_gallery_images" id="delete_gallery_images">
                    
                    <div class="row">
                        <?php $__currentLoopData = $listing->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="image_custom shadow"  style="background-image: url(<?php echo e(asset('listing_photos/gallery/'.$data->asset)); ?>);">
                                <span class="badge badge-danger float-right" id="image<?php echo e($data->id); ?>" onclick="del_image('<?php echo e($data->asset); ?>', '<?php echo e($data->id); ?>')">X</span>
                            </div>
                            
                            <div class="delete_image_overly text-center" id="image_over<?php echo e($data->id); ?>">
                                <span class="btn btn-info mt-5" onclick="restore_image('<?php echo e($data->id); ?>')">Restore</span>
                            </div>
                        </div> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                    
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-6 ">
                            <div class="form-group d-flex align-items-center mt-2">
                                <div class="switch m-r-10">
                                    <input type="checkbox" name="status" id="status" 
                                    <?php if($listing->status): ?>
                                    checked
                                    <?php endif; ?>
                                    >
                                    <label for="status"></label>
                                </div>
                                <label>Status</label>
                            </div>
                        </div>
                        <div class="col-6">
                            <button type="submit" class="btn btn-primary float-right">
                                <i class="anticon anticon-save"></i>
                                <?php echo e(__('Save')); ?>

                            </button>
                            
                        </div>
                    </div>
                    
                    <hr>
                    <div class="form-group">
                        <label for="time">Price <small class="text-muted">*</small></label>
                        <div class="input-group mb-3">
                            
                            <input type="number" name="price" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " value="<?php echo e(old('price') ?? $listing->price); ?>" placeholder="250" aria-label="150" aria-describedby="basic-addon2" required>
                            <div class="input-group-append">
                                <span class="input-group-text" id="basic-addon2">Lakhs</span>
                            </div>
                        </div>
                        
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-danger"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    
                    
                </div>
                
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="mt-2">Attributes <small class="text-muted">Optional</small></h5>
                </div>
                <div class="card-body">
                    <div class="accordion" id="accordion-default">
                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                                    <?php
                                        $dev_value = '';
                                        foreach ($listing->att_values as $item) {
                                            if ($item->attribute_id == $data->id) {
                                                $dev_value = $item->value;
                                            }
                                        }
                                    ?>
                                    
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title">
                                    <a data-toggle="collapse" href="#collapse<?php echo e($data->id); ?>">
                                        <span><?php echo e($data->name); ?></span>
                                    </a>
                                </h5>
                            </div>
                            <div id="collapse<?php echo e($data->id); ?>" class="collapse " data-parent="#accordion-default">
                                <div class="card-body">
                                    <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="att<?php echo e($data->id); ?>" value="<?php echo e($dev_value); ?>" placeholder="Value">
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>
    
</form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<!-- select js -->
<script src="<?php echo e(asset('backend/vendors/select2/select2.js')); ?>"></script>


<script src="<?php echo e(asset('backend/vendors/ckeditor/ckeditor.js')); ?>"></script>
<script>    
    window.onload = function() {   
        document.getElementById('delete_gallery_images').value = '';
    }

    // select 2
    $('.select2').select2()
    
    // CKeditor
    CKEDITOR.replace( 'description',{
        
    } 
    );
    
    
    
    
    
    var options = []; 
    
    function del_image(image, id){
        document.getElementById('image'+id).style.display = "none";
        document.getElementById('image_over'+id).style.display = "block";
        
        options.push(id);
        document.getElementById('delete_gallery_images').value = options.toString();
        
    }
    
    function restore_image(id){
        document.getElementById('image'+id).style.display = "block";
        document.getElementById('image_over'+id).style.display = "none";
        
        
        for( var i = 0; i < options.length; i++){ 
            
            if ( options[i] === id) { 
                
                options.splice(i, 1); 
            }
            
        }
        document.getElementById('delete_gallery_images').value = options.toString();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', ['page_action' => 'Add Listing'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Freelance\Lisiting Agency\lisiting-agency\resources\views/admin/listings/edit.blade.php ENDPATH**/ ?>