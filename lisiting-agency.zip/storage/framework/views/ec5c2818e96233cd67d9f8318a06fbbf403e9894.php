<?php echo e($slot); ?>

<?php /**PATH D:\Freelance\Lisiting Agency\lisiting-agency\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>